#include "../auxiliary_code/sope.h"

int input_parser(char* args[],bank_account_t * admin, int* nthr);