#include "../auxiliary_code/sope.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>

void log_reply(tlv_reply_t *reply);
void log_request(tlv_request_t *request);
