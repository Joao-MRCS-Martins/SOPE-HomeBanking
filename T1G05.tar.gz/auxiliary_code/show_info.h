#include "sope.h"

void show_usage_user();

void show_usage_server();

void show_request(tlv_request_t req);

void show_reply(tlv_reply_t rep);

void show_account(bank_account_t account);