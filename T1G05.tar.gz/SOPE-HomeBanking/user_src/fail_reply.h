#include "../auxiliary_code/sope.h"

void fail_reply(tlv_reply_t * rep, tlv_request_t * req, ret_code_t rc);