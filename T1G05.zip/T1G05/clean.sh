#!/usr/bin/env bash
 
 make clean
 rm ulog.txt
 rm slog.txt
 cd /tmp
 rm -rf secure_*